# SubHero fixes — fonts, admin 500, signup redirect

Copy every file in this folder into the repo at the SAME path (overwrite), then commit and deploy.

## What was wrong -> what changed
1. FONTS: input.css was edited but static/css/app.css was never rebuilt (Dockerfile only runs collectstatic),
   so prod still served the old CSS with a Google @import that the new CSP blocks. Also the CSS/preload
   pointed to .ttf filenames that do not exist (and DM Sans / DM Mono were never in the repo).
   -> Added 4 self-hosted woff2 files (~134 KB total), new @font-face rules, rebuilt app.css,
      fixed preload tags in base.html and base_admin.html.
2. ADMIN "TemplateDoesNotExist": admin and wallet templates {% include "icons/xxx.html" %} 26 icon files
   that were never created. -> Created all 26 (from the Feather set, same style as the existing nav icons).
3. SIGNUP ERROR after setting PIN: apps/accounts/views.py SetPINView did redirect("dashboard?registration_complete=1").
   Django treats that as a URL *name*, raises NoReverseMatch -> 500 page ("Return to Login").
   -> redirect(f'{reverse("dashboard")}?registration_complete=1') + added `from django.urls import reverse`.

## After copying
- Optional cleanup: delete static/fonts/BricolageGrotesque-VariableFont_opsz,wdth,wght.ttf (unused, 400 KB).
  KEEP static/fonts/Inter.ttf (used server-side for receipt images).
- Add to the Dockerfile/CI a CSS build step (npm ci && npm run build:css) OR keep committing app.css every time
  input.css or templates change, otherwise this will happen again.
- Deploy, then in a browser: F12 > Application > Service Workers > Unregister, Storage > Clear site data, reload.
